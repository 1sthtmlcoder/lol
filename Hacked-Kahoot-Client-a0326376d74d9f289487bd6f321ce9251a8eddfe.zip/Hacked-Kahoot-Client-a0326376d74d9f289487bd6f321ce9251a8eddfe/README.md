# This is a hacked client for the online game Kahoot.
## You can use the client on https://kahoot-jack.herokuapp.com/
## There is an invisible button at the bottom right of the website, pressing this brings up the modding menu. Also, once entering your game pin and username, you can type in the name of the quiz that you are completing and a rainbow line will appear around the correct answers.
### I will no longer offer support for this project.
